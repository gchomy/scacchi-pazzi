﻿using Amazon;
using Amazon.Runtime;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using System.Collections.Generic;
using System;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.DataModel;
using System.Linq;
using Amazon.S3;

namespace Sakk_Alkalmazás_2._0
{
	internal class dbclient
	{
		//DynamoDB client and context for DynamoDB handling
		public AmazonDynamoDBClient client;
		public DynamoDBContext context;
		//Logs in into the DB with provided credentials
		public dbclient()
		{
			var credentials = new BasicAWSCredentials("AKIAZKEVJAKK3VEZU2NI", "0qIMpp86J3QEdJbN1B7v7cj2WUOjqFamutEn2D2f");

			new AmazonS3Client(credentials, RegionEndpoint.EUCentral1);
			client = new AmazonDynamoDBClient(RegionEndpoint.EUCentral1);
			context = new DynamoDBContext(Amazon.RegionEndpoint.EUCentral1);
		}
		public void WaitUntilTableReady()
		{
			string tableName = "ChessMoves";
			string status = null;
			do
			{
				//checks the table info
				var res = client.DescribeTable(new DescribeTableRequest
				{
					TableName = tableName
				});
				status = res.Table.TableStatus;
			} while (status != "ACTIVE");
			//While loop that checks a table status until it gets ready
		}
		public void CreateTable()
		{
			//Lists the tables inside your account
			List<string> currentTables = client.ListTablesAsync().Result.TableNames;
			if (!currentTables.Contains("ChessMoves"))
			{
				var request = new CreateTableRequest
				{
					TableName = "ChessMoves",
					AttributeDefinitions = new List<AttributeDefinition>
					  {
						new AttributeDefinition
						{
						  AttributeName = "ID",
						  AttributeType = "N"
						},
						new AttributeDefinition
						{
						  AttributeName = "PlayerName",
						  AttributeType = "S"
						}
					  },
					KeySchema = new List<KeySchemaElement>
					  {
						new KeySchemaElement
						{
						  AttributeName = "ID",
						  KeyType = "HASH"
						},
						new KeySchemaElement
						{
						  AttributeName = "PlayerName",
						  KeyType = "RANGE"
						}
					  },
					ProvisionedThroughput = new ProvisionedThroughput
					{
						ReadCapacityUnits = 10,
						WriteCapacityUnits = 5
					},
				};
				var response = client.CreateTableAsync(request);
			}
		}
		public void InsertUsers(string d,string p)
		{
			var table = Table.LoadTable(client, "Users");
			Document Data = new Document();
			Data["nomeutente"] = d;
			Data["passwords"] = p;
			table.PutItem(Data);
		}
		public void InsertItem(LogMossa d)
		{
			var table = Table.LoadTable(client, "ChessMoves");
			Document Data = new Document();
			Data["postI"] = d.postI;
			Data["postJ"] = d.postJ;
			Data["preI"] = d.preI;
			Data["preJ"] = d.preJ;
			table.PutItem(Data);
		}
		public bool SearchUser(string l)
		{
		    var table = Table.LoadTable(client, "Users");
			ScanFilter scanFilter = new ScanFilter();
			scanFilter.AddCondition("ID", ScanOperator.IsNotNull);
			ScanOperationConfig config = new ScanOperationConfig()
			{
				Filter = scanFilter,
				Select = SelectValues.SpecificAttributes,
				AttributesToGet = new List<string> { "ID", "PlayerName", "postI", "postJ", "preI", "preJ" }
			};
			List<Document> documentList = new List<Document>();
			Search search = table.Scan(config);
			if (search.Count != 0)
			{
				return true;
			}
			return false;
		}
		/*public List<LogMossa> SearchItem()
		{
			Table DataTable = Table.LoadTable(client, "ChessMoves");
			ScanFilter scanFilter = new ScanFilter();
			scanFilter.AddCondition("ID", ScanOperator.IsNotNull);
			ScanOperationConfig config = new ScanOperationConfig()
			{
				Filter = scanFilter,
				Select = SelectValues.SpecificAttributes,
				AttributesToGet = new List<string> { "ID", "PlayerName", "postI", "postJ", "preI", "preJ" }
			};
			
		}*/
		public void DeleteTable(string tableName)
		{
			var request = new DeleteTableRequest
			{
				TableName = tableName
			};
		}
	}
		
}
